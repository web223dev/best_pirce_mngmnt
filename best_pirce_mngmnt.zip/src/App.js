import React from 'react';
import Routing from 'Routing';
import './App.css';

function App() {
    return (
        <div>
            <Routing/> 
        </div>
    );
}

export default App;
