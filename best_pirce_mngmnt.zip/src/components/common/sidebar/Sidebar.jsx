import React, { Component } from 'react';


class Sidebar extends Component {
    render() {
        return (
            <div>
                    <sidebar className="">
                       
                       
                    </sidebar>
            </div>
        );
    }
}

export default Sidebar;