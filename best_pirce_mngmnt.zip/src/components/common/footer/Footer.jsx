import React, { Component } from 'react';
import './footer.css';

class Footer extends Component {
    render() {
        return (
            <div className="footer-container-fluid">
                
            </div>
        );
    }
}

export default Footer;