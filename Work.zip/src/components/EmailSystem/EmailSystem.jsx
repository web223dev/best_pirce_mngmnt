import React, { Component } from 'react';


class EmailSystem extends Component {
    render() {
        return (
            <div>
                <h3>EmailSystem Test Page</h3>
            </div>
        );
    }
}

export default EmailSystem;