import React, { Component } from 'react';


class Prospects extends Component {
    render() {
        return (
            <div>
                <h3>Prospect Test Page</h3>
            </div>
        );
    }
}

export default Prospects;