import React, { Component } from 'react';


class Report extends Component {
    render() {
        return (
            <div>
                <h3>Report Test Page</h3>
            </div>
        );
    }
}

export default Report;