import React, { Component } from 'react';


class DayDeals extends Component {
    render() {
        return (
            <div>
                <h3>Day Deals Test Page</h3>
            </div>
        );
    }
}

export default DayDeals;